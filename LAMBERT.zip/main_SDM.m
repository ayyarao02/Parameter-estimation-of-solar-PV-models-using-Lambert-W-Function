%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%       Dr.Tummala.S.L.V.Ayyarao
%% https://scholar.google.co.in/citations?user=X7i25FAAAAAJ&hl=en&oi=sra
%% GMR Institute of Technology, India
%%  Parameter estimation using Lambert W Function
%% If you use the code, cite the below paper  
%% Ayyarao Tummala SLV, and G. Indira Kishore. "Parameter estimation of solar PV models with artificial humming bird optimization algorithm using various objective functions." Soft Computing 28, no. 4 (2024): 3371-3392.
%%  Parameter extraction of SDM
% close all
clear
clc
format long;
warning('off','all')
warning
SearchAgents_no=50; % Number of search agents
 
Max_iteration=1000; % Maximum numbef of iterations
global V Ie1 Ie Im
% Objective Function
tic
fobj=@SDM_Lambert;
lb=[0 0 0 0 1];
ub=[1 1 100 0.5 2];
dim=5;
BEst=zeros(1,30);
BESTT1=inf;
for i=1:1
[Best_score,Best_pos,AHO_cg_curve]=AHO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);%Success
BEst(i)=Best_score;
end
toc
% S=std(BEst);
% A=mean(BEst);
% B=min(BEst);
SDM_Lambert(Best_pos)
figure(1)
semilogy(AHO_cg_curve,'Color','r')
% title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
% % % % 
axis tight
grid on
box on
figure(2)
plot(V,Im,'LineWidth',2)
hold on
plot(V,Ie,'>','LineWidth',2,'MarkerFaceColor','black')
xlabel('Voltage')
ylabel('Current')
legend('measured','estimated')
figure(3)
plot(V, V.*Im,'LineWidth',2)
hold on
plot(V,V.*Ie,'>','LineWidth',2)
xlabel('Voltage')
ylabel('Power')
legend('measured','estimated')
